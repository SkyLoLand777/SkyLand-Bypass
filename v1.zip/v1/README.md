Current Status: `Working`

# Fluxus Key Bypasser V1
 - NO LONGER MAINTAINED. USE `V2` INSTEAD!

## To get it to work
 - Open the start url and complete the captcha, once it redirects you to the first linkvertise close the tab and run the program. Should work.

## How to run (WINDOWS)
- Download or clone this repo
- Run `install.bat` and and wait until it finishes installation
- Run `start.bat`
- Ok thats it

## How to run (others)
- Download or clone this repo
- Run `npm install` in console and and wait until it finishes installation
- Run `node index.js HWIDHERE` in console
- Ok thats it

## How to get HWID
- Whenever you press "Get Key" in Fluxus it opens this tab --> flux.li/windows/start.php?HWID=XXXX, copy all of XX until the end of the url
